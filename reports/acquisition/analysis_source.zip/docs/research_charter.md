# Research charter: learning relationships under changing conditions

Status: accepted research direction, updated after the conditional-reuse,
matched-history, and continued-acquisition studies. This is a research hypothesis and roadmap, not a new locked
experimental protocol or a claim that general continual learning is solved.

Project title: **Continual Relational Learning**.
Subtitle: **Learning when knowledge applies, and when it must change.**
ACP-CL remains the historical name of the critical-period experiments. Existing
package and command names preserve reproducibility of the archived studies.

## Objective and scope

Develop a general mechanism that learns representations from scratch, retains
useful knowledge through changes in conditions, and continues acquiring new
representations under bounded memory and computation.

The original relational premise remains a research direction: useful knowledge
describes how observations, entities, actions, and consequences depend on one
another, together with the conditions under which those dependencies apply.
An isolated observation is evidence; a learned conditional dependency is a
candidate unit of reusable knowledge. Explicit symbolic graphs are one possible
implementation, not a required architecture or an established necessity.

Joint persistence supplies a concrete definition of usefulness in the present
testbed: the probability that both participants remain functional through a
specified horizon. It is an experimenter's objective. We have not shown that
joint survival is necessary for continual learning, that it uniquely defines
improvement, or that the neural mechanism must consist of cooperating agents.

## Working hypothesis

**A continual learner should acquire new predictive relationships, preserve
relationships that remain useful, and revise those that no longer apply,
without exhausting its ability to learn.**

Our proposed route toward this requirement remains:

**In environments with recurring and changing dependencies, learning when stored
knowledge applies and where it needs revision can improve the tradeoff between
new learning and retention, relative to learners with the same observations,
history, and resource budgets.**

The proposed mechanism separates three operations:

1. Learn conditional predictors and their representations from experience.
2. Infer their current applicability from recent observations, actions, and outcomes.
3. Revise predictions or develop new representations when existing predictors
   repeatedly fail, while limiting damage to still-useful knowledge.

Unexpected feedback alone is insufficient evidence of a new relationship.
It may reflect stochastic outcomes, missing observations, poor calibration, or
an obsolete relationship. Distinguishing these cases is part of the hypothesis,
not an assumption that a novelty detector will already solve it.

## Minimal mathematical description

Let h_t contain only observations, performed actions, and outcomes available
before the current decision. Let phi_psi be a representation learned from
scratch, and let f_theta_k be a conditional predictor. A bounded library can
make predictions through

    p_hat_t(y | x, a) = sum_k q_t(k | x, h_t) f_theta_k(y | phi_psi(x), a).

Changing q_t reuses knowledge by changing which predictor applies. Changing
psi or theta learns or revises the underlying predictors. Allocation or
replacement of predictors is a possible additional operation, subject to a
fixed total resource budget; unbounded growth is not a solution to forgetting.
The reference prototype restricts applicability to q_t(k | h_t). A tested
bounded intervention let the present observation influence applicability too,
without receiving its outcome. That additive correction failed its new-learning
screen; the general formula is a hypothesis family, not a validated architecture.

In the current world, y includes survival at several finite horizons. In a
second world it may be another measurable outcome. Action selection uses the
declared task objective, while prediction and applicability remain distinct
parts of the mechanism.

Time enters at three levels: observations within an event, recent experience
used to infer present conditions, and retained knowledge across longer absences.
The current four-head model and 32-record window are implementation choices.
Neither a universal window length nor a universal critical-period schedule is
part of the hypothesis.

## Claims and current evidence

| Claim | Current status | What would strengthen or weaken it |
|---|---|---|
| Recent evidence can reactivate useful learned mappings. | Supported within the testbed: +11.60 points over pooling in the first pilot; +7.10 over a qualified recurrent learner with matched history in the follow-up, each positive in all eight seeds. | Test different environments, broader competitors, and longer change schedules. |
| Retaining experience helps later reuse. | Supported for the current recipe: +18.24 points over its current-only control on the return probe. | Determine whether the same tradeoff persists at smaller memory budgets and longer absences. |
| This mechanism preserves the ability to acquire new representations. | Not established. In the new physical-law diagnostic, retained weights were useful after optimizer/replay reset; that reset improved acquisition but worsened valid-old retention. The conditional delay-cue qualification check narrowly failed. | First qualify the weak cue on new development data, then separate optimizer and replay effects before selecting an intervention. |
| Relationships are a better representational unit than the alternatives. | Not directly established: the implementation uses neural predictors, not explicit relational structures. | Compare representations under controlled budgets and tests that require transfer of dependencies. |
| Joint persistence is a privileged general learning principle. | Untested. It is presently the chosen evaluation objective. | Separate objective effects from architecture effects; test ordinary prediction/control objectives as well. |

The [conditional-reuse report](../reports/conditional_results.md),
[matched-history report](../reports/contextual_results.md), and
[acquisition diagnostic](../reports/acquisition_results.md) are the empirical
references. The failed [experience-selection rule](../reports/persistence_results.md)
and earlier [dual-path pilot](../reports/dual_path_results.md) remain negative
results. Changes to the working hypothesis must be recorded explicitly rather
than interpreted as retroactive success of those mechanisms.

## Completed comparison and next bounded question

The matched-history comparison completed the first step of this roadmap:
qualified recurrence, returning conditions, a new dependency, feedback noise,
matched absence schedules, and one diagnosed routing intervention. All planned
seeds and branches completed. The routing correction failed the predefined
new-learning screen, while the original conditional learner retained stronger
old-condition reuse and valid-knowledge retention than the recurrent comparator.
The frozen-feature diagnostic showed that continued visual adaptation helped
the recurrent learner acquire the new dependency.

The subsequent acquisition diagnostic kept both architectures and introduced
three new physical dependencies, with continued, frozen-feature, reset-state,
and fresh-weight controls. It completed 12 prefixes and 180 episodes on six
new seeds. Resetting optimizer and replay improved acquisition but increased
valid-old damage in every seed average for both learners. Retained parameters
after state reset outperformed fresh initialization at the same arrival and
update budget. There was no clear pooled acquisition-AUC benefit from feature
updates, although freezing substantially reduced learning of the supply-timing
cue. These endpoints answer different questions and should not be conflated.

Qualification is incomplete: the conditional fresh-model delay-cue benefit was
.00193868 against a required .002. The narrow miss stays a failure. It prevents
treating the complete diagnostic as qualified; it does not invalidate every
observation or establish a failure of the broad hypothesis. No late-versus-early
result establishes a causal loss of plasticity with age.

The next bounded question is whether optimizer history, replayed experience,
or their interaction explains the acquisition/retention tradeoff. Qualify the
weak cue on new development seeds, then compare keeping/resetting optimizer
crossed with keeping/resetting replay, holding learned weights and recent
history fixed. A full reset is not the proposed solution: it harmed still-useful
knowledge. Select a bounded intervention only after isolating the responsible
state. Autonomous triggering remains separate from these privileged diagnostic
resets. Do not tune on the completed comparison seeds.

Continue separating four cases, concealed from ordinary learners:

* A familiar relationship returns after intervening experience.
* A new physical dependency requires learning a previously irrelevant cue.
* A previously useful cue changes meaning, making some old predictions obsolete.
* Feedback becomes noisier while underlying dynamics remain unchanged.

Primary measurements should concern new-dependency acquisition under fixed
exposure. Guardrails must cover old-condition reuse, valid-knowledge retention,
and inappropriate adaptation to noise. Declare minimum useful gains and maximum
acceptable losses before the comparison, report uncertainty, and keep all seeds.
A better old-condition score alone does not satisfy the new-learning objective.
Equal parameters and raw data do not imply equal computation; report remaining
work differences and treat each independent seed as the statistical unit.

A learner that improves new acquisition by erasing useful mappings has not met
the combined objective. Generality also remains open while all evidence comes
from this world. After a candidate clears the acquisition and retention screen,
test a second environment with independently changed observations and dynamics,
then longer streams. Separate representation, memory, applicability inference,
and objective choice. Critical-period scheduling remains optional and unproven.

## Position relative to prior work and project identity

Contextual inference is an established research direction. The
[COIN motor-learning theory](https://cbl.eng.cam.ac.uk/lengyel/publications/heald-nature-2021/)
distinguishes updating memories from changing their expression. That distinction
is relevant to the present reuse result; it does not validate our architecture
or its joint-persistence objective. [Caccia et al.](https://proceedings.mlr.press/v232/caccia23a.html)
study recurrent replay for task-agnostic continual reinforcement learning and
provide a reason to include a strong history-aware comparison. This project is
not currently a reproduction of either method or a demonstrated novel algorithm.

Continual Relational Learning describes the broader research question without
requiring a particular plasticity mechanism. It is a descriptive working title,
not a claim to an exclusive technical term. The successful current prototype is
more specifically an evidence-routed conditional predictor with replay.

Critical periods can remain an optional hypothesis about when and where to
permit change. ACP-CL can remain the name of that historical experimental line.
A later project rename should preserve source archives and reproducible commands;
the research identity and a package-path migration are separate decisions.
