# Setup, reproduction, and method reference

The [project README](../README.md) summarizes the hypothesis and outcomes. This
guide preserves the detailed installation, command, and comparison reference.
Run commands from the repository root, even though this guide lives in `docs/`.
Archived numerical results require their recorded source and runtime.

## Setup

Use Python 3.10 for the closest match to recorded experiments. Install from the repository root in a fresh virtual environment. These platform-specific commands follow the [official PyTorch 2.8.0 instructions](https://pytorch.org/get-started/previous-versions/#v280).

Windows, CPU only:

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

Linux, CPU only:

```bash
python3.10 -m venv .venv
.venv/bin/python -m pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cpu
.venv/bin/python -m pip install -e ".[dev]"
```

macOS on Apple Silicon uses PyPI wheels, without a CUDA or Linux/Windows CPU index:

```bash
python3.10 -m venv .venv
.venv/bin/python -m pip install torch==2.8.0 torchvision==0.23.0
.venv/bin/python -m pip install -e ".[dev]"
```

For CUDA 12.8 on Windows or Linux, replace the CPU index in that platform's command with `https://download.pytorch.org/whl/cu128`. CUDA requires a compatible NVIDIA driver. Use `--device cpu` on macOS; this runner does not select MPS. The archived image experiments used Windows, Python 3.10.11, PyTorch 2.8.0+cu128, NumPy 2.2.6, and an RTX 4070 Ti. These setup instructions do not claim bitwise numerical reproduction on other systems.

[requirements-lock.txt](../requirements-lock.txt) records that Windows/CUDA package environment, including `+cu128` versions. It is not a portable CPU or macOS lockfile. To install the recorded versions in a fresh Windows/CUDA environment, first install Torch/torchvision from the CUDA index as above, then run:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt -e ".[dev]"
```

Python itself, drivers, hardware, and source revision are separate requirements. Reproducing archived results requires their recorded source and runtime. Ordinary CPU setup and CI exercise the dependency ranges in `pyproject.toml`, not the archived CUDA environment. Dataset and generated training files live in ignored `data/` and `runs/` directories.

## Run

Commands below use the Windows interpreter. On Linux/macOS, substitute `.venv/bin/python` and use forward slashes in repository paths.

The completed [v2 protocol](../docs/experiment_v2.md) covers local critical periods for replaced units, a frozen input drift sensor, oracle and reset/gain controls, and fixed-label recurring shape domains. Running an archived configuration with current code creates a new experiment; the [v2 report](../reports/v2_results.md) identifies the historical training revision.

```powershell
.venv\Scripts\python.exe -m acp_cl run --config configs\v2_shapes_development.json --output runs\my_v2_development --device cuda
.venv\Scripts\python.exe -m acp_cl run --config configs\v2_shapes_long.json --output runs\my_v2_long --device cuda
```

The corresponding `v2_gaussian.json`, `v2_shapes_stationary.json`, and
`v2_shapes_noise_only.json` configurations define the geometry audit and
100-experience negative controls. These datasets require no downloads.
Yoked controls must run after `acp_v2` for the same seed; the suite orders them
automatically. Oracle and yoked results are labeled extra-information diagnostics.

```powershell
# Small deterministic engineering check, no downloads or GPU required
.venv\Scripts\python.exe -m acp_cl run --config configs\smoke.json --output runs\my_smoke --device cpu

# Paired development pilot, eight synthetic experiences and five seeds
.venv\Scripts\python.exe -m acp_cl run --config configs\synthetic_pilot.json --output runs\my_synthetic --device cpu

# Documented calibration: activates closure/reopening on three development seeds
.venv\Scripts\python.exe -m acp_cl run --config configs\synthetic_calibrated.json --output runs\my_calibrated --device cpu

# Real images: twenty CIFAR-100 classes, small CNN, three development seeds
.venv\Scripts\python.exe -m acp_cl run --config configs\cifar100_pilot.json --output runs\my_cifar --device cuda

# Full 100-class ResNet development template; substantially more compute
.venv\Scripts\python.exe -m acp_cl run --config configs\cifar100_resnet18.json --output runs\my_resnet --device cuda
```

The CIFAR commands download the official dataset if absent. If the Toronto origin's single connection is slow, first run `.venv\Scripts\python.exe scripts\download_cifar100.py`; it fetches canonical byte ranges and verifies torchvision's official archive checksum.

Override methods or seeds with `--methods er er_recycle acp --seeds 11 22 33`. Add `--resume` to the **same command/output** to continue completed-experience checkpoints or reuse completed results. Changed configurations, source versions, execution devices, or recorded runtimes require a fresh output directory. Only resume trusted local checkpoints. Analyze existing results with `.venv\Scripts\python.exe -m acp_cl analyze runs\my_cifar`.

Each suite writes `manifest.json`, per-method/seed results, allocation traces, events, checkpoints, paired bootstrap summaries, CSV, and PNG/SVG plots. When `scratch_reference` is enabled, a separate fresh-model diagnostic trains on each experience's identical current-data sequence; v3 disables it. Reported studies evaluate **validation** images and keep test data outside development decisions.

`configs/resnet_gpu_smoke.json` runs twenty updates per method with all 100 output labels to check GPU integration quickly. It is intentionally too short for an accuracy conclusion.

## Completed v3 study

The [v3 report](../reports/v3_results.md), [protocol](../docs/experiment_v3.md), [allocation rules](../docs/algorithm_v3.md), and [machine-readable study plan](../configs/v3_study.json) separate development from locked evaluation. `v3_study.json` is an orchestration plan, not an individual `acp_cl run --config` file.

Check all seven v3 methods locally without downloading data:

```powershell
.venv\Scripts\python.exe -m acp_cl run --config configs/v3_smoke.json --output runs/my_v3_smoke --device cpu
```

To prepare the development grid:

```powershell
.venv\Scripts\python.exe scripts/prepare_v3_study.py prepare-development --spec configs/v3_study.json --configs configs/v3/development
```

Run all eight generated JSON configurations through the ordinary CLI, using `runs/v3_development/<configuration-stem>` for each output. For example:

```powershell
.venv\Scripts\python.exe -m acp_cl run --config configs/v3/development/gain_005_recurring.json --output runs/v3_development/gain_005_recurring --device cuda
```

After the complete development grid finishes, select using development results only:

```powershell
.venv\Scripts\python.exe scripts/prepare_v3_study.py select --spec configs/v3_study.json --results runs/v3_development --output configs/v3/reproduction_lock
```

Selection records the attempted candidates and emits three locked configurations only if the prespecified screen passes. The committed `configs/v3/locked` directory preserves the original selection; use a fresh lock directory for an independent reproduction because result-byte hashes include runtime and timing. Freeze the new `selection.json` and its configurations in local git before evaluating the new seeds. Run each of `recurring.json`, `stationary.json`, and `early_biased.json` with its matching `runs/v3_reproduction/<condition>` output; for example:

```powershell
.venv\Scripts\python.exe -m acp_cl run --config configs/v3/reproduction_lock/recurring.json --output runs/v3_reproduction/recurring --device cuda
```

The plan screens four gains for replay plus recycling on two development seeds, then locks one shared gain before evaluating three different seeds. The completed study selected 0.5 and contains 67 comparative runs: 16 development, 42 recurrent/stationary, and nine early-color-bias runs. Colors are independent of labels during ordinary training and all evaluation; the biased curriculum changes an initial training segment. All attempted development candidates, per-seed results, and the separate engineering smokes are recorded in the [inventory](../reports/v3/run_inventory.json).

| Method | Intervention |
|---|---|
| `er_v3` | Replay and a fixed feature gain, without recycling |
| `recycle_v3` | Add a fixed reset-count/time schedule |
| `newborn_v3` | Add a local gain window after replacement |
| `newborn_matched_v3` | Redistribute mature gain to match the baseline's nominal feature budget before clipping |
| `protection_v3` | Extend replacement eligibility age |
| `consolidation_v3` | Add local consolidation after maturation |
| `full_v3` | Combine gain, protection, and consolidation |

These are individual-component comparisons against a shared baseline plus a combined condition, not a full factorial or isolated leave-one-out study. All conditions share a warmup and optimizer-displacement cap. Keeping mature gain unchanged and matching total nominal gain are different comparisons; post-clipping gains and actual displacements need not match. The protocol defines selection, measurements, and failure reporting. The report preserves the modest positive primary result, negative final-accuracy contrasts, stationary ceiling, and seed-dependent early-bias interaction.

## CIFAR-10 transfer pilot

The [transfer protocol](../docs/cifar10_transfer_protocol.md) carries the v3 recipe
to natural images with fixed labels and one current arrival per training image.
It compares replay, recycling, newborn gain, and nominal-budget-matched newborn
gain on recurring original/grayscale/blur domains and a stationary control.
The [pre-run lock](../configs/cifar10_transfer/lock.json) binds the source,
configuration, runtime, two development seeds, and a 16-run budget. Its
continuation rule is an effort-allocation decision, not a significance test.

The [completed report](../reports/cifar10_transfer_results.md),
[all seed outcomes](../reports/cifar10_transfer/summary.md), and
[independent audit](../reports/cifar10_transfer/independent_audit.md) preserve the
negative result. Both seeds and every planned method are included.

Prepare the official training archive once; the constructor below downloads and
extracts it if needed. Official test images and labels are not evaluated.

```powershell
.venv/Scripts/python.exe -c "from torchvision.datasets import CIFAR10; CIFAR10(root='data', train=True, download=True)"
.venv/Scripts/python.exe -m acp_cl run --config configs/cifar10_transfer/recurring.json --output runs/my_transfer/recurring --device cuda --no-plots
.venv/Scripts/python.exe -m acp_cl run --config configs/cifar10_transfer/stationary.json --output runs/my_transfer/stationary --device cuda --no-plots
```

If the download is slow, `scripts/download_cifar100.py --dataset cifar10`
provides the checksum-verified ranged download before the constructor extracts
it. The separate `configs/cifar10_transfer_smoke.json` checks all four methods
quickly on already downloaded data; its accuracy is not evidence of efficacy.
Offline stream tests use fixtures and require no dataset download.

Use the study-specific analysis instead of generic bootstrap summaries:

```powershell
.venv/Scripts/python.exe scripts/summarize_cifar10_transfer.py --runs runs/my_transfer --output runs/my_transfer_report
.venv/Scripts/python.exe scripts/audit_cifar10_transfer.py --results runs/my_transfer --summary runs/my_transfer_report/summary.json --output runs/my_transfer_report
.venv/Scripts/python.exe scripts/plot_cifar10_transfer.py --archive runs/my_transfer_report/individual_results.json --output runs/my_transfer_report
```

These commands use a fresh report directory. The committed archive preserves
the original outcomes and raw-byte identities. Plotting alone can use that
archive without downloading data or loading checkpoints. Numerical audits use
trusted local raw runs and their recorded lock/source/runtime.

Source was frozen at `c250129` and the run lock at `3f72cd8`. A new runtime or
changed recipe requires a separate output and a newly declared study identity.
The earlier v3 archive, including hashes of then-current root documentation,
remains the historical snapshot at `a038786`; subsequent root documentation
does not replace that sealed snapshot.

## Comparisons

| Command method | Behavior |
|---|---|
| `finetune` | Current data only |
| `er` | Fixed-budget reservoir replay |
| `er_recycle` | Replay plus the same low-utility recycling used by ACP; CBP-inspired |
| `derpp` | Replay labels plus stored-logit MSE; documented DER++ variant |
| `fixed` | Initial broad learning, scheduled closure, no later reopening |
| `acp` | Signal-driven closure, bounded local reopening, consolidation, replay, recycling |
| `acp_no_consolidation`, `acp_no_replay`, `acp_no_recycling` | Component-removal controls |
| `acp_global`, `acp_no_relaxation`, `acp_no_reopening` | Locality and reopening controls |
| `acp_no_damage`, `acp_no_health`, `acp_random_recycling` | Sensor and replacement-selection controls |
| `acp_v2` | Local newborn periods, frozen input drift, fixed initial schedule, mature reopening |
| `acp_v2_no_newborn`, `acp_v2_no_reopening`, `acp_v2_learned_sensor` | V2 mechanism controls |
| `acp_v2_oracle` | Extra-information diagnostic with true signal-domain change times |
| `er_recycle_yoked`, `er_recycle_yoked_gain` | Extra-information controls with v2's recorded reset schedule; optional constant matched mean gain |

The head is always trainable; no task ID or per-task output mask is used. Image models include an explicit recyclable adapter so channel resetting does not break residual/GroupNorm dependencies. The optimizer gates momentum displacement and separately tracks consolidation anchors and importance-window origins. See the algorithm document for exact departures from the original proposal and cited methods.

The important endpoints are final accuracy, forgetting, and late-stream early-learning AUC. AUC includes retained knowledge and transfer as well as adaptation. Where measured, scratch-adjusted AUC is a diagnostic rather than pure forward transfer. AUC divided by the first experience's AUC is deliberately omitted. Small-seed bootstrap intervals are exploratory; sparse forgetting can miss intervening damage, and equal data exposure is not equal compute.

The ingredients have substantial predecessors: mature low-utility replacement in [continual backpropagation](https://www.nature.com/articles/s41586-024-07711-7), importance-based protection in [Synaptic Intelligence](https://proceedings.mlr.press/v70/zenke17a.html), combined protection and plasticity in [UPGD](https://arxiv.org/abs/2404.00781), and persistent early-experience effects in [critical learning periods](https://arxiv.org/abs/1711.08856). This repository studies particular combinations and controls. It does not claim discovery of those ideas, biological equivalence, or a validated solution to continual learning.

[Closer maturation and neurogenesis precedents](../docs/algorithm_v3.md#close-computational-precedents) also include Neurogenesis Deep Learning, NICE, and a neuromorphic lifelong-learning preprint with preferential newborn plasticity and age-gated pruning.


## Verification and historical snapshots

The earlier image-study CPU suite passed 546 tests with three platform/device skips.
Eight separate CIFAR-10 engineering runs covered all four methods on CPU and
GPU. The older v3 revision also passed its clean-clone installation check.
These checks verify implementation; they do not establish efficacy or
cross-platform bitwise reproduction. See the individual study reports for
run identities and independent local audits.

The v3 artifact seal refers to commit `a038786`. The CIFAR-10 transfer seal
refers to `5985b77`. Both include the root documentation as it stood at those
commits; later README edits do not replace those historical snapshots.

## Continual Relational Learning: matched-history comparison

The research umbrella is now Continual Relational Learning. The installed
package remains `acp_cl`, and the earlier `acp-cl` commands remain compatible.
See the [accepted charter](research_charter.md) and
[matched-history protocol](contextual_comparison.md).

The new runner shares each learned prefix across three independent branches:
returning conditions, a new visible dependency, and feedback noise. Its two
absence schedules contain exactly the same training records in different orders.
The locked pilot uses eight seeds, six methods, two gap orders, and three branches:
96 prefix fits and 288 branches. Twelve updates per incoming batch were selected
by the finite comparator-development grid, using different seeds and excluding
the candidate from setting selection.

```powershell
.venv/Scripts/python.exe -m acp_cl.contextual.study --config configs/contextual_smoke.json --output runs/contextual_smoke_new --device cpu
.venv/Scripts/python.exe -m acp_cl.contextual.study --config configs/contextual_pilot.json --output runs/contextual_reproduction --device cpu --protocol docs/contextual_comparison.md
.venv/Scripts/python.exe scripts/summarize_contextual.py --input runs/contextual_reproduction --output reports/contextual_reproduction
.venv/Scripts/python.exe scripts/audit_contextual.py --input runs/contextual_reproduction --output reports/contextual_reproduction/audit.json
.venv/Scripts/python.exe scripts/plot_contextual.py --input reports/contextual_reproduction
```

Use a fresh output directory for a new experiment. After interruption, add
`--resume` with the identical config, source, and runtime. Prefix checkpoints
are saved after each prefix block; branch checkpoints are saved every 256
arrivals. Resuming repeats unfinished work, never skips it. Only load trusted
local PyTorch checkpoints. Cross-platform bitwise reproduction is not promised.

Every development attempt is preserved under `reports/contextual/development/`,
including its config, full outcomes, source archive, and checkpoint audit.
The old plain-GRU configs predate the `interaction_features` field and need
their own archived training source; do not silently retrofit them to the latest
runner. To audit such a locally retained run with its exact source:

```powershell
.venv/Scripts/python.exe scripts/audit_contextual.py --input runs/contextual_development_u3 --output reports/contextual_development_u3_audit.json --archived-source runs/contextual_audit_sources/reproduction_plain
```

`--archived-source` checks every source-file hash, writes it to the named
directory, and launches a separate process with that source on `PYTHONPATH`.
For retraining an older recipe, use that extracted source as `PYTHONPATH` and
its archived `config.json`; use a fresh output directory. Full checkpoints stay
under the ignored `runs/` tree, while the portable reports include exact
training sources and all outcomes. Two development seeds cannot establish
candidate superiority; the fresh cohort must independently pass adequacy checks.

## Continued acquisition diagnostic

The [acquisition protocol](acquisition_diagnostic.md) adds three predictive
dependencies to the same conserving world. Their image signals are present but
irrelevant from the start; the physical rules later make each signal useful.
The original conditional and qualified recurrent learners remain unchanged.
At each introduction, compare continued learning, frozen visual features,
reset optimizer/replay with retained weights, and fresh random weights. Only
the continuing arm advances the trajectory. Final independent branches test
an exact return, an obsolete cue meaning, and noisy reports.

```powershell
.venv/Scripts/python.exe scripts/check_acquisition_world.py --output runs/acquisition_world_check_new.json
.venv/Scripts/python.exe -m acp_cl.acquisition.study --config configs/acquisition_smoke.json --output runs/acquisition_smoke_new --device cpu
.venv/Scripts/python.exe -m acp_cl.acquisition.study --config configs/acquisition_development_2048.json --output runs/acquisition_development_new --device cpu --protocol docs/acquisition_diagnostic.md
.venv/Scripts/python.exe scripts/summarize_acquisition.py --input runs/acquisition_development_new --output runs/acquisition_development_report
```

The original development used only fresh-model fits on seeds 211/212 and
selected 2,048 arrivals, the first passing entry in the declared exposure grid.
The 4,096 and 8,192 configuration files are unrun grid entries. A new independent
study must complete its own development and lock its settings before evaluating
comparison seeds. The commands below reproduce the selected original recipe:

```powershell
.venv/Scripts/python.exe -m acp_cl.acquisition.study --config configs/acquisition_diagnostic.json --output runs/acquisition_reproduction --device cpu --protocol docs/acquisition_diagnostic.md
.venv/Scripts/python.exe scripts/summarize_acquisition.py --input runs/acquisition_reproduction --output runs/acquisition_reproduction_report
.venv/Scripts/python.exe scripts/audit_acquisition.py --input runs/acquisition_reproduction --output runs/acquisition_reproduction_report/audit.json
.venv/Scripts/python.exe scripts/plot_acquisition.py --input runs/acquisition_reproduction_report
```

The comparison has six independent seeds, two architectures, 12 prefix fits,
144 acquisition arms, and 36 final branches. Episodes are not independent
replicates: acquisition contrasts average the three introductions within seed
before bootstrap. Primary error measures average predictions over actions and
survival horizons; this need not improve the best one-time transfer decision.
Fresh-model cue-use qualification must be rechecked in the comparison cohort.
The engineering smoke is too short for scientific qualification.

Use fresh output directories; append `--resume` to the identical training
command after interruption. Exact source, runtime and config identities are
required. The runner saves prefix checkpoints after each prefix block and
episode checkpoints every 256 arrivals, together with episode-start weights.
The audit regenerates performed-action records and replay state, verifies each
diagnostic fork, and recomputes initial/final probes. It requires trusted local
checkpoints and the exact source recorded in the run. Intermediate curves are
retained and checked against checkpoint records, but are not all independently
recomputed from intermediate weights. Plotting uses the portable summary only.

Original training sources, protocol locks, all episode records, development
selection, and audits are under `reports/acquisition/`; full model checkpoints
remain in the ignored `runs/` tree. Existing study archives stay unchanged.
