# Research charter: learning relationships under changing conditions

Status: accepted research direction, updated after the conditional-reuse,
matched-history, continued-acquisition, and optimizer-by-replay studies.
The replay-renewal and evidence-consolidation studies and their failed screens
are now recorded.
This is a research hypothesis and roadmap, not a new locked
experimental protocol or a claim that general continual learning is solved.

Working project title: **Adam**. Optional expansion: **Adaptive Dynamics and
Associative Memory**. Continual relational learning describes its research
direction; the acronym is a proposal, not a claim of a validated mechanism.
Subtitle: **Learning when knowledge applies, and when it must change.**
ACP-CL remains the historical name of the critical-period experiments. Existing
package and command names preserve reproducibility of the archived studies.

## Objective and scope

Develop a general mechanism that learns representations from scratch, retains
useful knowledge through changes in conditions, and continues acquiring new
representations under bounded memory and computation.

The original relational premise remains a research direction: useful knowledge
describes how observations, entities, actions, and consequences depend on one
another, together with the conditions under which those dependencies apply.
An isolated observation is evidence; a learned conditional dependency is a
candidate unit of reusable knowledge. Explicit symbolic graphs are one possible
implementation, not a required architecture or an established necessity.

Joint persistence supplies a concrete definition of usefulness in the present
testbed: the probability that both participants remain functional through a
specified horizon. It is an experimenter's objective. We have not shown that
joint survival is necessary for continual learning, that it uniquely defines
improvement, or that the neural mechanism must consist of cooperating agents.

## Working hypothesis

**A continual learner should acquire new predictive relationships, preserve
relationships that remain useful, and revise those that no longer apply,
without exhausting its ability to learn.**

Our proposed route toward this requirement remains:

**In environments with recurring and changing dependencies, learning when stored
knowledge applies and where it needs revision can improve the tradeoff between
new learning and retention, relative to learners with the same observations,
history, and resource budgets.**

The proposed mechanism separates three operations:

1. Learn conditional predictors and their representations from experience.
2. Infer their current applicability from recent observations, actions, and outcomes.
3. Revise predictions or develop new representations when existing predictors
   repeatedly fail, while limiting damage to still-useful knowledge.

Unexpected feedback alone is insufficient evidence of a new relationship.
It may reflect stochastic outcomes, missing observations, poor calibration, or
an obsolete relationship. Distinguishing these cases is part of the hypothesis,
not an assumption that a novelty detector will already solve it.

## Minimal mathematical description

Let h_t contain only observations, performed actions, and outcomes available
before the current decision. Let phi_psi be a representation learned from
scratch, and let f_theta_k be a conditional predictor. A bounded library can
make predictions through

    p_hat_t(y | x, a) = sum_k q_t(k | x, h_t) f_theta_k(y | phi_psi(x), a).

Changing q_t reuses knowledge by changing which predictor applies. Changing
psi or theta learns or revises the underlying predictors. Allocation or
replacement of predictors is a possible additional operation, subject to a
fixed total resource budget; unbounded growth is not a solution to forgetting.
The reference prototype restricts applicability to q_t(k | h_t). A tested
bounded intervention let the present observation influence applicability too,
without receiving its outcome. That additive correction failed its new-learning
screen; the general formula is a hypothesis family, not a validated architecture.

In the current world, y includes survival at several finite horizons. In a
second world it may be another measurable outcome. Action selection uses the
declared task objective, while prediction and applicability remain distinct
parts of the mechanism.

Time enters at three levels: observations within an event, recent experience
used to infer present conditions, and retained knowledge across longer absences.
The current four-head model and 32-record window are implementation choices.
Neither a universal window length nor a universal critical-period schedule is
part of the hypothesis.

## Claims and current evidence

| Claim | Current status | What would strengthen or weaken it |
|---|---|---|
| Recent evidence can reactivate useful learned mappings. | Supported within the testbed: +11.60 points over pooling in the first pilot; +7.10 over a qualified recurrent learner with matched history in the follow-up, each positive in all eight seeds. | Test different environments, broader competitors, and longer change schedules. |
| Retaining experience helps later reuse. | Supported in the earlier pilot (+18.24 points over current-only on return) and by broader retention and noise resistance with uniform replay in later studies. The fixed 8/8 split does not meet the combined requirements. | Test which experience remains useful and which updates protect that knowledge, under bounded memory and computation. |
| This mechanism preserves the ability to acquire new representations. | Not established. Both replay-renewal cohorts pass fresh-model learnability checks. Packet deletion and age rebasing improve local acquisition. Continuous 8/8 replay improves acquisition in every seed but fails retention and extra-noise-cost limits in both architectures. The later acceptance diagnostic shares draft training and cannot establish improved representation learning. | Develop a new evidence-guided candidate on fresh data; preserve the declared acquisition, retention, return, revision and noise requirements. |
| Relationships are a better representational unit than the alternatives. | Not directly established: the implementation uses neural predictors, not explicit relational structures. | Compare representations under controlled budgets and tests that require transfer of dependencies. |
| Joint persistence is a privileged general learning principle. | Untested. It is presently the chosen evaluation objective. | Separate objective effects from architecture effects; test ordinary prediction/control objectives as well. |

The [conditional-reuse report](../reports/conditional_results.md),
[matched-history report](../reports/contextual_results.md), and
[acquisition diagnostic](../reports/acquisition_results.md), and
[optimizer-by-replay diagnostic](../reports/training_state_results.md), and
[replay-renewal studies](../reports/replay_renewal_results.md) are the empirical
references. The failed [experience-selection rule](../reports/persistence_results.md)
and earlier [dual-path pilot](../reports/dual_path_results.md) remain negative
results. Changes to the working hypothesis must be recorded explicitly rather
than interpreted as retroactive success of those mechanisms.

## Completed comparison and next bounded question

The matched-history comparison completed the first step of this roadmap:
qualified recurrence, returning conditions, a new dependency, feedback noise,
matched absence schedules, and one diagnosed routing intervention. All planned
seeds and branches completed. The routing correction failed the predefined
new-learning screen, while the original conditional learner retained stronger
old-condition reuse and valid-knowledge retention than the recurrent comparator.
The frozen-feature diagnostic showed that continued visual adaptation helped
the recurrent learner acquire the new dependency.

The subsequent acquisition diagnostic kept both architectures and introduced
three new physical dependencies, with continued, frozen-feature, reset-state,
and fresh-weight controls. It completed 12 prefixes and 180 episodes on six
new seeds. Resetting optimizer and replay improved acquisition but increased
valid-old damage in every seed average for both learners. Retained parameters
after state reset outperformed fresh initialization at the same arrival and
update budget. There was no clear pooled acquisition-AUC benefit from feature
updates, although freezing substantially reduced learning of the supply-timing
cue. These endpoints answer different questions and should not be conflated.

Qualification is incomplete: the conditional fresh-model delay-cue benefit was
.00193868 against a required .002. The narrow miss stays a failure. It prevents
treating the complete diagnostic as qualified; it does not invalidate every
observation or establish a failure of the broad hypothesis. No late-versus-early
result establishes a causal loss of plasticity with age.

The optimizer-by-replay follow-up completed 72 fresh development fits, selected
8,192 arrivals, and ran 12 prefixes plus 372 comparison episodes on six new
seeds. Both architectures passed every fresh-model qualification group; their
delay-cue benefits were .005120 and .005016 against the declared .002 threshold.
This qualifies the new study without changing the previous failure.

With Adam retained, replay reset improved new-learning Brier AUC by .009743
conditional and .009626 recurrent, each positive improvement in all six seed
averages. Adam reset alone had little acquisition effect. Relative to ordinary
continuation, replay reset reduced conditional valid-old damage by .012093
but increased recurrent damage by .017901. Conditional damage still remained
positive in absolute terms. Its retention interaction also made resetting both
states worse than replay reset alone during acquisition.

The final controls limit that result: clearing replay improved prediction in
the returned world while worsening broader valid-old retention for both
architectures, and increased their vulnerability to corrupted feedback. The
same operation therefore helps adaptation and can undermine history-dependent
reliability. No blanket reset satisfies the combined research objective.

The next two studies held optimizer state fixed. A first-introduction diagnostic
separated packet deletion, effective reservoir age and random generators across
12 shared prefixes and 84 episodes. Deletion and rebasing both improved
factorial-mean acquisition while worsening mean valid-old retention. Resetting
random generators alone supplied no clear benefit. This local diagnosis does
not test repeated autonomous resets.

A separate fixed-policy cohort compared uniform, recent-only and an 8/8 split
through 36 prefixes and 288 episodes. Both experiments and their analysis were
locked before the first main fit. The equal split was specified directly,
without the roadmap's proposed tuning stage or a policy-development selection
cohort. It was not selected using either new cohort's outcomes. Any subsequently
tuned variant still requires independent development data.

Split reduced acquisition Brier AUC by .004667 conditional and .005237 recurrent,
improving all six paired seeds per architecture. Terminal valid-old error rose
by .023090 and .014030, against a .005 maximum mean increase. Extra matched-noise
penalties rose by .006165 and .006081, also above .005. Both architectures fail
the combined screen; all qualification and survival requirements pass. Several
retention intervals are wide, so the pilot's failed means are not proof of a
tolerance violation in every setting. All failures remain failures under the
unchanged prospective rule.

Uniform replay remains the working reference. The next bounded hypothesis is
whether persistent predictive evidence can guide which relationships to update
while protecting still-valid knowledge. A candidate must distinguish changed
dependencies from noisy reports using observed experience, with no privileged
change labels. This is a proposed direction, not a validated solution or a
license to rename the earlier failed selection rule. Use new development data
and explicit controls before another locked comparison. Do not tune on the
completed reset or policy seeds.

Continue separating four cases, concealed from ordinary learners:

* A familiar relationship returns after intervening experience.
* A new physical dependency requires learning a previously irrelevant cue.
* A previously useful cue changes meaning, making some old predictions obsolete.
* Feedback becomes noisier while underlying dynamics remain unchanged.

Primary measurements should concern new-dependency acquisition under fixed
exposure. Guardrails must cover old-condition reuse, valid-knowledge retention,
and inappropriate adaptation to noise. Declare minimum useful gains and maximum
acceptable losses before the comparison, report uncertainty, and keep all seeds.
A better old-condition score alone does not satisfy the new-learning objective.
Equal parameters and raw data do not imply equal computation; report remaining
work differences and treat each independent seed as the statistical unit.

A learner that improves new acquisition by erasing useful mappings has not met
the combined objective. Generality also remains open while all evidence comes
from this world. After a candidate clears the acquisition and retention screen,
test a second environment with independently changed observations and dynamics,
then longer streams. Separate representation, memory, applicability inference,
and objective choice. Critical-period scheduling remains optional and unproven.

## Accepted extension: evidence and lifetime performance

The user proposed testing whether short-term costs can be recovered through
longer-term usefulness. The [evidence-consolidation diagnostic](evidence_consolidation_protocol.md)
therefore extends evaluation to an 18-block continuous stream now, with a
prospective cumulative physical-prediction endpoint and matched early/late
cycles. New-dependency acquisition, returns, retained valid predictions, noise
and survival remain declared constraints. This changes the primary endpoint
for this bounded diagnostic; it does not reinterpret a failed earlier screen
or replace the general objective of learning new representations.

All acceptance policies share the same draft learning trajectory. They test
whether future predictive evidence improves commitment decisions, without
claiming that this changes representation learning. Better lifetime deployment,
better later acquisition, and farther-future planning are different claims.
The first is measured here. The latter two remain unestablished; outcome
labels still end at H=12, and novel cues are introduced early in the stream.

The [focused related-work review](adam_related_work.md) records close precedents,
including Paired Learners, SEA, persistence-based adaptation and complementary
learning systems. Neither delayed consolidation nor its future-evidence test
is claimed as a new general principle. A possible contribution must come from
a specific effective mechanism, a useful controlled diagnosis, or a benchmark
whose distinct value is established against appropriate alternatives.

Persistent reporting corruption can produce the same observed distribution as
changed physical dynamics. The proposed test uses a declared corruption family;
repetition is useful evidence only under assumptions that distinguish the
possibilities. Clean physical outcomes are evaluator-only and never supplied
to the learner or acceptance rule.

### Completed evidence-consolidation result

The [fixed pilot](../reports/evidence_consolidation_results.md) completed all
12 draft trajectories, 216 continuous blocks and 36 fresh references. Both
architectures pass every fresh qualification group. Development's separate
two-seed delay-cue failures remain recorded. The sustained acceptance rule
fails both architectures' prospective screens.

Whole-stream Brier increases by .001685 conditional and .002800 recurrent
versus immediate deployment, worsening every one of six seed pairs in each
architecture. Noisy-block error improves by .002050 and .011011, but return
error increases by .007811 and .016244, exceeding the allowed .005 cost.
Sustained makes only small uncertain overall gains over fixed delay and
one-packet evidence. Acquisition, still-valid retention, noise and survival
guardrails pass; lifetime gain and return requirements fail.

The late-minus-early advantage versus immediate is slightly positive on
average (.000660 and .000702), but both paired-seed intervals include zero.
Late error remains worse and accumulated costs are not recovered. This is
not evidence of a compounding representation benefit; the underlying draft
learning is identical by construction. The physical horizon also remains H=12.

Keep immediate uniform replay as the reference. The next bounded diagnosis
should separate the age of deployed weights, context inference and available
retained predictions on matched return queries. A subsequent candidate could
use evidence to direct selective changes during learning, requiring fresh
development data and an independent protocol. Testing whether earlier learning
helps later acquisition also requires matched novel dependencies introduced
late in life. Do not tune the failed acceptance rule on these completed seeds.

## Position relative to prior work and project identity

Contextual inference is an established research direction. The
[COIN motor-learning theory](https://cbl.eng.cam.ac.uk/lengyel/publications/heald-nature-2021/)
distinguishes updating memories from changing their expression. That distinction
is relevant to the present reuse result; it does not validate our architecture
or its joint-persistence objective. [Caccia et al.](https://proceedings.mlr.press/v232/caccia23a.html)
study recurrent replay for task-agnostic continual reinforcement learning and
provide a reason to include a strong history-aware comparison. This project is
not currently a reproduction of either method or a demonstrated novel algorithm.

Adam is the working project name. Continual relational learning describes the
broader question without requiring a particular plasticity mechanism. The
optional expansion, Adaptive Dynamics and Associative Memory, makes no claim
to an exclusive technical term or a successful general algorithm. The current
reference is an evidence-routed conditional predictor with uniform replay.

Critical periods can remain an optional hypothesis about when and where to
permit change. ACP-CL can remain the name of that historical experimental line.
The Adam name preserves source archives and reproducible commands; package
paths and CLI names stay `acp_cl` and `acp-cl`.
