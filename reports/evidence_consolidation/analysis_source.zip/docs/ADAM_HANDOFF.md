# Adam research handoff

Updated 2026-09-27 after the evidence-consolidation experiment.

## Current result

The requested repeated-evidence study is complete and audited. Read
reports/evidence_consolidation_results.md and the full tables under
reports/evidence_consolidation/pilot/summary.md.

Both architectures pass every pilot fresh-model qualification group and fail
the prospective acceptance-rule screen. Sustained minus immediate Brier x100:

| Outcome | Conditional | Recurrent |
|---|---:|---:|
| Whole stream | +0.169 | +0.280 |
| Final matched cycle | +0.083 | +0.267 |
| Original environment returns | +0.781 | +1.624 |
| Noisy periods | -0.205 | -1.101 |

Whole-stream error increases in all six seeds per architecture. The mean
late-minus-early advantage is slightly positive (+0.066 and +0.070 scaled),
but both intervals include zero. Costs are not recovered by stream end.
Sustained beats fixed delay in four of six seeds in each architecture, with
small uncertain gains below the required magnitude. Acquisition, valid-old,
noise and survival guardrails pass; lifetime gain and return requirements fail.
Development's two-seed arrival-delay qualification failures remain failures.

Immediate use of the uniformly replay-trained learner remains the reference.
Do not tune the gate on completed seeds or promote it as a successful method.

## What was tested

Working title Adam; optional expansion Adaptive Dynamics and Associative Memory.
Keep acp_cl and repository paths for compatibility. The general objective is
learning representations from scratch under bounded memory and computation.

The experiment shares one continuously trained draft across four deployment
policies. An eight-packet future-data window evaluates a frozen proposal against
frozen committed weights before feedback. Periodic always accepts; single uses
its first gain >.002; sustained needs mean gain >.002 and six positive packets.
Accepted weights are exactly those evaluated. Immediate uses live draft weights.
No state resets or privileged condition labels enter learning or acceptance.

Each main trajectory contains 151,552 arrivals: a 4,096-arrival prefix followed
by eighteen blocks of 8,192. Three new dependencies precede three cycles of
clean conditions, noise, recovery, original-base return and revised cue meaning.
Persistent noise is used in cycles one and three; burst noise in cycle two.
Noise arrangement and learner age were not counterbalanced. Physical labels
still end at H=12. Every packet is scored before training on evaluator-only
clean physical outcomes; gates only see reported terminal outcomes.

This tests deployment/acceptance, not different representation-learning rules:
all policies share the same draft. It cannot demonstrate compounding
representation learning, acquisition of new cues late in life, farther-future
planning, or general identification of physical change versus reporting bias.

## Reproducibility and verification

Protocol: docs/evidence_consolidation_protocol.md.
Sources: src/acp_cl/evidence_consolidation/.
Configs: configs/evidence_consolidation_{smoke,development,pilot}.json.
Runs: runs/evidence_consolidation_{smoke,development,pilot}.
Portable reports: reports/evidence_consolidation/.

Both source/config/protocol locks predate development fitting. The 39-file
analysis lock predates pilot fitting. No locked file changed. Shared scientific
source SHA256:
e95a0b9823ed139a099a547f5b5c96196ba9266b09c1e3ddbe62b68186dff11d

Development seeds 11001--11002: 4 trajectories, 72 blocks, 12 fresh references,
4 prefixes; audit passed 172 checkpoint states and 2,368 windows, with 264
stable files validated. Pilot seeds 12001--12006: 12 trajectories, 216 blocks,
36 fresh references, 12 prefixes; audit passed 516 states and 7,104 windows,
with 784 stable files validated. All planned fits completed without retries,
interruptions or exclusions. The pilot finished at 21:33:11 UTC. Four single-
thread CPU workers used affinity mask 85. No GPU or ongoing training remains.

Engineering checks passed 818 distinct tests with two existing Windows symlink
skips. Ruff and whitespace checks passed. Independent recomputation from raw
pilot JSON reproduced primary means, paired contrasts, bootstrap intervals and
screen decisions. All 273 artifacts in six older archives and their scientific
source files retain their hashes; before/after records are in the new archive.

The audit reconstructs streams/replay/history, budgets, exact checkpoint
continuity, endpoint probes, first-packet prequential scores and gate gains,
and every recorded acceptance decision and snapshot lineage. Intermediate
window weights are not all saved; not every intermediate gain or prediction
was independently rescored or retrained. This is not an independent replication.

Useful commands (see docs/reproduction.md):

    python scripts/verify_evidence_consolidation_archive.py --input reports/evidence_consolidation
    python scripts/plot_evidence_consolidation.py --input reports/evidence_consolidation/pilot

Do not overwrite the prospective lock or older sealed archives. The portable
archive contains original raw records and hashes, source ZIPs, protocol/config
locks, final analysis, audits and figures. Local trusted model checkpoints
remain in ignored runs/. No commit or external publication was requested.

## Next research question

Before another large experiment, separate deployed-weight age, retained
predictions and context inference on matched return queries. Then consider a
bounded mechanism that uses evidence to direct selective changes during
learning without delaying every deployed update. Any new candidate needs fresh
development data, explicit resource controls, and independent confirmation.
To test compounding acquisition, introduce matched novel dependencies both early
and late, counterbalance their order, and include matched fresh-weight controls.

The broader project remains an experimental research direction, not a proven
new algorithm. docs/adam_related_work.md records close precedents including
Paired Learners (2008), SEA (2001), PeARL, CLS-ER and COIN.
docs/evidence_noise_limits.md explains why repeated evidence against corrupted
reports does not by itself identify changes in physical dynamics.

The user authorized this study, novelty/horizon assessment and agent help.
Agents completed bounded design, test, literature and independent review tasks.
No inline visualization was created because browser preview was unavailable;
verified PNG/SVG/PDF scientific figures are linked in the report.
