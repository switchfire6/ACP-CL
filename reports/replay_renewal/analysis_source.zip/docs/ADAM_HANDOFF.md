# Adam research handoff

Active authorization: user requested continuing the next experiments, and likes
Adam as a working project name. Proposed acronym: Adaptive Dynamics and
Associative Memory (optional, not a scientific claim). Keep `acp_cl` paths.

Prior completed study: `reports/training_state_results.md`; 372 episodes,
qualified references, full checkpoint audit passed. Its sealed 53-artifact
archive and all earlier scientific source must remain unchanged. Replay reset
helped acquisition but caused return/noise costs. No general CL solution exists.

Current work: implement and finish BOTH fixed experiments in
`docs/replay_renewal_protocol.md`, with no outcome-dependent tuning:
reset decomposition, seeds 9001--9006, 12 prefixes/84 episodes; continuous
uniform/recent/8+8 split, seeds 10001--10006, 36 prefixes/288 episodes including
36 fresh references. Four one-thread workers, Windows affinity mask 85.

Implementation, summaries and full checkpoint auditor are complete. Engineering
smokes (14 and 48 episodes) and audits passed; smoke qualification failures are
expected and are not scientific attempts. Full suite: 733 passed, 2 Windows
skips; ruff passed. Analysis formulas and tests were archived before main fits
in `reports/replay_renewal/analysis_at_lock.zip` and `.json`.

BOTH main cohorts are locked under `runs/replay_renewal_decomposition` and
`runs/replay_renewal_policy`. Shared scientific source SHA256:
`6f3561f485bf5dad9577be231b2542bba0c4682ac0b847e03f385b1c57271d39`.
Do not edit ANY training source or either config/protocol during these fits.
Decomposition COMPLETED all 84 episodes and 12 prefixes, without interruption.
Summary, full audit (12 prefixes, 84 starts, 84 finals) and all 280 file-integrity
checks PASSED. Both architectures pass all fresh checks (8 groups). Audit
session 7790 completed. Report has detailed reset results: packet deletion and
age rebasing both improve factorial-mean acquisition but cost old knowledge.
Full-reset AUC differences x100: conditional -.4224, recurrent -.5492 (all six
seeds improve each); terminal valid-old differences +1.0749, +3.2990. RNG reset
alone has intervals crossing zero; after clear+rebase it worsens acquisition.
Main decomposition figure rendered and visually inspected.
Policy COMPLETED all 288 episodes and 36 prefixes at about 2026-09-27 19:52 UTC,
without interruption or retry. Session 66048 is finished. Summary is complete;
all 12 fresh-reference groups PASS, but the fixed split FAILS its policy screen
in BOTH architectures (retention and extra noise penalty). All 940 stable files
passed integrity checks. Full policy audit PASSED: 36 prefixes, 288 starts,
288 finals, 36 clean/noise pairs. Audit session 41653 finished. Do not resume
completed sessions 10325, 66048 or 41653. Both new cohorts completed with no
interruptions, exclusions or retries. All 1,220 stable files passed inspection.

Policy effects split minus uniform (Brier x100): acquisition -.4667 conditional,
-.5237 recurrent, all six seeds improve each; terminal valid-old error +2.3090,
+1.4030; extra noise penalty +.6165, +.6081 (limit+.5). All fresh, acquisition,
consistency, final prediction means and survival gates pass. Conditional fails
all retention gates; recurrent passes clean retention but fails the other
retention gates. Some intervals are wide; retain the mean-based failure and
do not claim every harm exceeds tolerance conclusively. Uniform remains the
working baseline. Proposed next direction: persistent predictive evidence to
guide relationship updates/protection, requiring new development data.

Report, README, charter, math note, reproduction guide and figures are complete.
Figures were visually inspected. All earlier archive/source hashes and local
documentation links were checked. The portable snapshot is under
`reports/replay_renewal/`; `verify_replay_renewal_archive.py` checks its seal,
original raw result hashes and unchanged prospective analysis. The experimental
work is complete; future work should start from a new development protocol.
No outcome-based changes/retries.
No sub-agent delegation, publication or commits authorized. Keep all prior
archives and scientific source unchanged.

Inline memory explainer created using Visualize skill at
`C:/Users/pounc/Desktop/Code/adam-replay-visual/adam-memory.html` (outside repo).
Final reply MUST include its visualization content reference on its own line:
`visualize{"path":"C:/Users/pounc/Desktop/Code/adam-replay-visual/adam-memory.html"}`.
It is an illustrative sampler, not measured learning results. Checked actual
keyboard Home/End interactions, 320/360/736 layouts, light/dark, no errors.
Fragment and verification are archived in memory_visual.zip / checks.json.
Reload the full visualize skill before creating or updating a visualization.
Skill path: C:/Users/pounc/.codex/plugins/cache/openai-bundled/visualize/1.0.22/skills/visualize/SKILL.md.
Temporary preview servers sessions 73834 (8769) and 19874 (8770) were stopped
after QA. All experiment and audit sessions are complete.

Context answer: retained summary and durable files are sufficient to continue;
no reliable fullness meter or guarantee of lossless conversation compaction.
OpenAI Docs skill read; official sources opened:
https://developers.openai.com/api/docs/guides/compaction
https://developers.openai.com/blog/run-long-horizon-tasks-with-codex
